/*

 *  saveCXI.cpp
 *  cheetah
 *
 *  Created by Jing Liu on 05/11/12.
 *  Copyright 2012 Biophysics & TDB @ Uppsala University. All rights reserved.
 *
 */

#include <string>
#include <vector>

#include "saveCXI.h"

herr_t
cheetahHDF5ErrorHandler(hid_t, void *)
{
  // print the error message
  H5Eprint(H5E_DEFAULT, stderr);
  // abort such that we get a stack trace to debug
  abort();
}

template <class T>
hid_t get_datatype(const T * foo){
  hid_t datatype;
  if(typeid(T) == typeid(short)){
    datatype = H5T_NATIVE_INT16;
  }else if(typeid(T) == typeid(unsigned short)){
    datatype = H5T_NATIVE_UINT16;
  }else if((typeid(T) == typeid(int)) || (typeid(T) == typeid(bool))){
    datatype = H5T_NATIVE_INT32;
  }else if(typeid(T) == typeid(unsigned int)){
    datatype = H5T_NATIVE_UINT32;
  }else if(typeid(T) == typeid(long)){
    datatype = H5T_NATIVE_LONG;
  }else if(typeid(T) == typeid(unsigned long)){
    datatype = H5T_NATIVE_ULONG;
  }else if(typeid(T) == typeid(float)){
    datatype = H5T_NATIVE_FLOAT;
  }else if(typeid(T) == typeid(double)){
    datatype = H5T_NATIVE_DOUBLE;
  }else if(typeid(T) == typeid(char)){
    datatype = H5T_NATIVE_CHAR;
  }else{
    ERROR("Do not understand type: %s",typeid(T).name());
  }
  return datatype;
}

template <class T>
static T * generateThumbnail(const T * src,const int srcWidth, const int srcHeight, const int scale)
{
  int dstWidth = srcWidth/scale;
  int dstHeight = srcHeight/scale;
  T * dst = new T [srcWidth*srcHeight];
  for(int x = 0; x <dstWidth; x++){
    for(int y = 0; y<dstHeight; y++){
      double res=0;
      for (int xx = x*scale; xx <x*scale+scale; xx++){
	for(int yy = y*scale; yy <y*scale+scale; yy++){
	  res += src[yy*srcWidth+xx];
	} 
      }
      dst[y*dstWidth+x] = res/(scale*scale);
    }
  }
  return dst;
}

static uint getStackSlice(CXI::File * cxi){
#ifdef __GNUC__
  return __sync_fetch_and_add(&(cxi->stackCounter),1);
#else
  pthread_mutex_lock(&global->framefp_mutex);
  uint ret = cxi->stackCounter;
  cxi->stackCounter++;
  pthread_mutex_unlock(&global->framefp_mutex);
  return ret;
#endif
}

static hid_t createScalarStack(const char * name, hid_t loc, hid_t dataType){
  hsize_t dims[1] = {CXI::initialStackSize};
  hsize_t maxdims[1] = {H5S_UNLIMITED};
  hid_t cparms = H5Pcreate(H5P_DATASET_CREATE);
  hid_t dataspace = H5Screate_simple(1, dims, maxdims);
  if( dataspace<0 ) {ERROR("Cannot create dataspace.\n");}
  /* Modify dataset creation properties, i.e. enable chunking  */
  H5Pset_chunk(cparms, 1, dims);
  //  H5Pset_deflate (cparms, 2);
  hid_t dataset = H5Dcreate(loc, name, dataType, dataspace, H5P_DEFAULT, cparms, H5P_DEFAULT);
  if( dataset<0 ) {ERROR("Cannot create dataset.\n");}

  const char * axis = "experiment_identifier";
  hsize_t one = 1;
  hid_t datatype = H5Tcopy(H5T_C_S1);
  H5Tset_size(datatype, strlen(axis));
  hid_t memspace = H5Screate_simple(1,&one,NULL);
  hid_t attr = H5Acreate(dataset,"axes",datatype,memspace,H5P_DEFAULT,H5P_DEFAULT);
  H5Awrite(attr,datatype,axis);
  H5Aclose(attr);
  H5Sclose(memspace);
  H5Sclose(dataspace);
  H5Pclose(cparms);
  return dataset;
}

template <class T> 
static void writeScalarToStack(hid_t dataset, uint stackSlice, T value){
  hid_t hs,w;
  hsize_t count[1] = {1};
  hsize_t offset[1] = {stackSlice};
  hsize_t stride[1] = {1};
  hsize_t block[1] = {1};
  /* dummy */
  hsize_t mdims[1];
 
  hid_t dataspace = H5Dget_space (dataset);
  if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
  H5Sget_simple_extent_dims(dataspace, block, mdims);
  /* check if we need to extend the dataset */
  if(block[0] <= stackSlice){
    while(block[0] <= stackSlice){
      block[0] *= 2;
    }
    H5Dset_extent(dataset, block);
    /* get enlarged dataspace */
    H5Sclose(dataspace);
    dataspace = H5Dget_space (dataset);
    if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
  }
  block[0] = 1;
  hid_t memspace = H5Screate_simple (1, block, NULL);
  hid_t type = get_datatype(&value);

  hs = H5Sselect_hyperslab (dataspace, H5S_SELECT_SET, offset,stride, count, block);
  if( hs<0 ) {ERROR("Cannot select hyperslab.\n");}
  w = H5Dwrite(dataset, type, memspace, dataspace, H5P_DEFAULT, &value) < 0;
  if( w<0 ){
    ERROR("Cannot write to file.\n");
    abort();
  }

  H5Sclose(memspace);
  H5Sclose(dataspace);
}


/* Create a 2D stack. The fastest changing dimension is along the width */
static hid_t create2DStack(const char *name, hid_t loc, int width, int height, hid_t dataType){
  hsize_t dims[3] = {CXI::initialStackSize,height,width};
  hsize_t maxdims[3] = {H5S_UNLIMITED,height,width};
  hid_t dataspace = H5Screate_simple(3, dims, maxdims);
  if( dataspace<0 ) {ERROR("Cannot create dataspace.\n");}
  hid_t cparms = H5Pcreate (H5P_DATASET_CREATE);
  H5Pset_chunk(cparms, 3, dims);
  //  H5Pset_deflate (cparms, 2);
  hid_t dataset = H5Dcreate(loc, name, dataType, dataspace, H5P_DEFAULT, cparms, H5P_DEFAULT);
  if( dataset<0 ) {ERROR("Cannot create dataset.\n");}
  H5Pset_chunk_cache(H5Dget_access_plist(dataset),H5D_CHUNK_CACHE_NSLOTS_DEFAULT,1024*1024*16,1);

  const char * axis = "experiment_identifier:y:x";
  hsize_t one = 1;
  hid_t datatype = H5Tcopy(H5T_C_S1);
  H5Tset_size(datatype, strlen(axis));
  hid_t memspace = H5Screate_simple(1,&one,NULL);
  hid_t attr = H5Acreate(dataset,"axes",datatype,memspace,H5P_DEFAULT,H5P_DEFAULT);
  H5Awrite(attr,datatype,axis);
  H5Aclose(attr);
  H5Sclose(memspace);
  H5Sclose(dataspace);
  H5Pclose(cparms);
  return dataset;    
}

template <class T> 
static void write2DToStack(hid_t dataset, uint stackSlice, T * data){  
  hid_t hs,w;
  hsize_t count[3] = {1,1,1};
  hsize_t offset[3] = {stackSlice,0,0};
  /* stride is irrelevant in this case */
  hsize_t stride[3] = {1,1,1};
  hsize_t block[3];
  /* dummy */
  hsize_t mdims[3];
  /* Use the existing dimensions as block size */
  hid_t dataspace = H5Dget_space (dataset);
  if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
  H5Sget_simple_extent_dims(dataspace, block, mdims);
  /* check if we need to extend the dataset */
  if(block[0] <= stackSlice){
    while(block[0] <= stackSlice){
      block[0] *= 2;
    }
    H5Dset_extent (dataset, block);
    /* get enlarged dataspace */
    H5Sclose(dataspace);
    dataspace = H5Dget_space (dataset);
    if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
  }
  block[0] = 1;
  hid_t memspace = H5Screate_simple (3, block, NULL);
  hid_t type = get_datatype(data);

  hs = H5Sselect_hyperslab (dataspace, H5S_SELECT_SET, offset,stride, count, block);
  if( hs<0 ) {
    ERROR("Cannot select hyperslab.\n");
  }
  w = H5Dwrite (dataset, type, memspace, dataspace, H5P_DEFAULT, data);
  if( w<0 ){
    ERROR("Cannot write to file.\n");
  }
  H5Sclose(memspace);
  H5Sclose(dataspace);
}

template <class T> 
static void createAndWriteDataset(const char *name, hid_t loc, T *data,int width=1, int height=0, int length=0){
  hid_t datatype,w;
  int ndims;
  hid_t dataspace;
  hsize_t dims1[1] = {width};
  hsize_t dims2[2] = {width,height};
  hsize_t dims3[3] = {width,height,length};
  datatype = get_datatype(data);
  if(height == 0 && length==0){
    ndims = 1;
    dataspace = H5Screate_simple(ndims, dims1, dims1);
  }else if(length==0){
   ndims = 2; 
   dataspace = H5Screate_simple(ndims, dims2, dims2);
   }else{
    ndims = 3;
    dataspace = H5Screate_simple(ndims, dims3, dims3);
  }
  if( dataspace<0 ) {ERROR("Cannot create dataspace.\n");}
  hid_t dataset = H5Dcreate(loc, name, datatype, dataspace, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  w = H5Dwrite(dataset, datatype, H5S_ALL, H5S_ALL, H5P_DEFAULT, data);  
  if( w<0 ){
    ERROR("Cannot write to file.\n");
  }
  H5Dclose(dataset);
  H5Sclose(dataspace);
}

static hid_t createStringStack(const char * name, hid_t loc, int maxSize = 128){
  /* FM: This is probably wrong */
  hid_t datatype = H5Tcopy(H5T_C_S1);
  H5Tset_size(datatype, maxSize);
  hsize_t dims[1] = {CXI::initialStackSize};
  hsize_t maxdims[1] = {H5S_UNLIMITED};
  hid_t cparms = H5Pcreate (H5P_DATASET_CREATE);
  hid_t dataspace = H5Screate_simple(1, dims, maxdims);
  H5Pset_chunk (cparms, 1, dims);
  //  H5Pset_deflate(cparms, 2);
  hid_t dataset = H5Dcreate(loc, name, datatype, dataspace, H5P_DEFAULT, cparms, H5P_DEFAULT);
  if( dataset<0 ){
    ERROR("Cannot create dataset.\n");
  }

  const char * axis = "experiment_identifier";
  hsize_t one = 1;
  datatype = H5Tcopy(H5T_C_S1);
  H5Tset_size(datatype, strlen(axis));
  hid_t memspace = H5Screate_simple(1,&one,NULL);
  hid_t attr = H5Acreate(dataset,"axes",datatype,memspace,H5P_DEFAULT,H5P_DEFAULT);
  
  H5Awrite(attr,datatype,axis);
  H5Aclose(attr);
  H5Sclose(memspace);
  H5Sclose(dataspace);
  H5Pclose(cparms);
  return dataset;    
}

static void writeStringToStack(hid_t dataset, uint stackSlice, const char * value){
  hid_t sh,w;
  hsize_t count[1] = {1};
  hsize_t offset[1] = {stackSlice};
  hsize_t stride[1] = {1};
  hsize_t block[1] = {1};
  /* dummy */
  hsize_t mdims[1];

  
  hid_t dataspace = H5Dget_space (dataset);
  if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
  H5Sget_simple_extent_dims(dataspace, block, mdims);
  /* check if we need to extend the dataset */
  if(block[0] <= stackSlice){
    while(block[0] <= stackSlice){
      block[0] *= 2;
    }
    H5Dset_extent(dataset, block);
    /* get enlarged dataspace */
    H5Sclose(dataspace);
    dataspace = H5Dget_space (dataset);
    if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
  }
  block[0] = 1;
  hid_t memspace = H5Screate_simple (1, block, NULL);

  hid_t type = H5Tcopy(H5T_C_S1);
  H5Tset_size(type, strlen(value));

  sh = H5Sselect_hyperslab (dataspace, H5S_SELECT_SET, offset,stride, count, block);
  if( sh<0 ) {ERROR("Cannot select hyperslab.\n");}
  w = H5Dwrite(dataset, type, memspace, dataspace, H5P_DEFAULT, value);
  if( w<0 ){
    ERROR("Cannot write to file.\n");
    abort();
  }
  H5Sclose(memspace);
  H5Sclose(dataspace);
}

/*

CXI file skeleton

|
LCLS
|  |
|  |-... (just copied from XTC)
|
entry_1
   |
   |- data_1 ---------
   |                  |
   |- instrument_1    | symlink
   |   |              |
   |   |-detector_1 <-----------------------------
   |   |   |                                      |
   |   |   |- data [raw data, 3D array]           |
   |   |   |- (mask) [raw masks, 3D array]        |
   |   |   |- mask_shared [raw mask, 2D array]    | 
   |   |   |- ...                                 | symlink
   |   .   .                                      |
   |                                              |
   |- (image_1)                                   |
   |    |                                         |
   |    |- detector_1 ----------------------------|
   |    |- data [assembled data, 3D array]        |
   |    |- (mask) [assembled masks, 3D array]     |
   |    |- mask_shared [assembled mask, 2D array] |
   |    |- ...                                    |
   |    .                                         |
   |                                              |
   |- (image_2)                                   |
   |    |                                         |
   |    |- detector_1 ----------------------------
   |    |- data [downsampled assembled data, 3D array]
   |    |- (mask) [downsampled assembled masks, 3D array]
   |    |- mask_shared [downsampled assembled mask, 2D array] 
   |    |- ...
   .    .
 
*/


static CXI::File * createCXISkeleton(const char * filename,cGlobal *global){
  /* Creates the initial skeleton for the CXI file.
     We'll rely on HDF5 automatic error reporting. It's usually loud enough.
  */

  CXI::File * cxi = new CXI::File;
  hid_t fid = H5Fcreate(filename,H5F_ACC_TRUNC,H5P_DEFAULT,H5P_DEFAULT);
  if( fid<0 ) {ERROR("Cannot create file.\n");}
  cxi->self = fid;
  cxi->stackCounter = 0;
  hsize_t dims[3];

  /* Create /cxi_version */
  dims[0] = 1;
  hid_t dataspace = H5Screate_simple(1, dims, dims);
  if( dataspace<0 ) {ERROR("Cannot create dataspace.\n");}
  hid_t dataset = H5Dcreate(cxi->self, "cxi_version", H5T_NATIVE_INT, dataspace, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  H5Dwrite (dataset, H5T_NATIVE_INT, H5S_ALL, H5S_ALL, H5P_DEFAULT, &CXI::version);

  /* /entry_1 */

  // /entry_1
  cxi->entry.self = H5Gcreate(cxi->self,"/entry_1", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);

  // /entry_1/experiment_identifier
  cxi->entry.experimentIdentifier = createStringStack("experiment_identifier",cxi->entry.self);

  // /entry_1/instrument_1
  cxi->entry.instrument.self = H5Gcreate(cxi->self, "/entry_1/instrument_1", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);

  // /entry_1/instrument_1/source_1
  cxi->entry.instrument.source.self = H5Gcreate(cxi->self,"/entry_1/instrument_1/source_1", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  // /entry_1/instrument_1/source_1/energy
  cxi->entry.instrument.source.energy = createScalarStack("energy",cxi->entry.instrument.source.self,H5T_NATIVE_DOUBLE);
  // /entry_1/instrument_1/experiment_identifier -> /entry_1/experiment_identifier
  H5Lcreate_soft("/entry_1/experiment_identifier",cxi->entry.instrument.source.self,"experiment_identifier",H5P_DEFAULT,H5P_DEFAULT);

  DETECTOR_LOOP{
    char detectorPath[1024];
    char dataName[1024];
    char imageName[1024];
    
    // /entry_1/instrument_1/detector_i
    sprintf(detectorPath,"/entry_1/instrument_1/detector_%ld",detID+1);
    CXI::Detector d;
    d.self = H5Gcreate(cxi->entry.instrument.self, detectorPath, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
    // /entry_1/data_i -> /entry_1/instrument_1/detector_i
    sprintf(dataName,"data_%ld",detID+1);
    H5Lcreate_soft(detectorPath,cxi->entry.self,dataName,H5P_DEFAULT,H5P_DEFAULT);

    d.distance = createScalarStack("distance", d.self,H5T_NATIVE_DOUBLE);
    d.description = createStringStack("description",d.self);
    d.xPixelSize = createScalarStack("x_pixel_size",d.self,H5T_NATIVE_DOUBLE);
    d.yPixelSize = createScalarStack("y_pixel_size",d.self,H5T_NATIVE_DOUBLE);
    
    /* Raw images */
    if(global->saveRaw){
      // /entry_1/instrument_1/detector_i/data
      d.data = create2DStack("data", d.self, global->detector[detID].pix_nx, global->detector[detID].pix_ny, H5T_STD_I16LE);
      if(global->savePixelmask){
	// /entry_1/instrument_1/detector_i/mask
	d.mask = create2DStack("mask", d.self, global->detector[detID].pix_nx, global->detector[detID].pix_ny, H5T_NATIVE_UINT16);
      }
      // /entry_1/instrument_1/detector_i/mask_shared
      createAndWriteDataset("mask_shared", d.self, global->detector[detID].pixelmask_shared, global->detector[detID].pix_nx, global->detector[detID].pix_ny);
      // /entry_1/instrument_1/detector_i/thumbnail
      d.thumbnail = create2DStack("thumbnail", d.self, global->detector[detID].pix_nx/CXI::thumbnailScale, global->detector[detID].pix_ny/CXI::thumbnailScale, H5T_STD_I16LE);
      // /entry_1/instrument_1/detector_i/experiment_identifier -> /entry_1/experiment_identifier
      H5Lcreate_soft("/entry_1/experiment_identifier",d.self,"experiment_identifier",H5P_DEFAULT,H5P_DEFAULT);
    }
    cxi->entry.instrument.detectors.push_back(d);

    /* Assembled images */
    if(global->saveAssembled){
      // /entry_1/image_i
      sprintf(imageName,"/entry_1/image_%ld",detID+1);
      CXI::Image img;
      img.self = H5Gcreate(cxi->entry.self, imageName, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
      // /entry_1/image_i/data
      long image_ny = global->detector[detID].image_nn/global->detector[detID].image_nx;
      img.data = create2DStack("data", img.self, global->detector[detID].image_nx, image_ny, H5T_STD_I16LE);
      if(global->savePixelmask){
	// /entry_1/image_i/mask
	img.mask = create2DStack("mask", img.self, global->detector[detID].image_nx, image_ny, H5T_NATIVE_UINT16);
      }
      // /entry_1/image_i/mask_shared
      uint16_t *image_pixelmask_shared = (uint16_t*) calloc(global->detector[detID].image_nn,sizeof(uint16_t));
      assemble2Dmask(image_pixelmask_shared, global->detector[detID].pixelmask_shared, global->detector[detID].pix_x, global->detector[detID].pix_y, global->detector[detID].pix_nn, global->detector[detID].image_nx, global->detector[detID].image_nn, global->assembleInterpolation);
      createAndWriteDataset("mask_shared", img.self, image_pixelmask_shared, global->detector[detID].image_nx, image_ny);
      // /entry_1/image_i/detector_1
      H5Lcreate_soft(detectorPath,img.self,"detector_1",H5P_DEFAULT,H5P_DEFAULT);
      // /entry_1/image_i/source_1
      H5Lcreate_soft("/entry_1/instrument_1/source_1",img.self,"source_1",H5P_DEFAULT,H5P_DEFAULT);
      // /entry_1/image_i/data_type
      img.dataType = createStringStack("data_type",img.self);
      // /entry_1/image_i/data_space
      img.dataSpace = createStringStack("data_space",img.self);
      // /entry_1/image_i/thumbnail
      img.thumbnail = create2DStack("thumbnail", img.self, global->detector[detID].image_nx/CXI::thumbnailScale, global->detector[detID].image_nx/CXI::thumbnailScale, H5T_STD_I16LE);
      // /entry_1/image_i/experiment_identifier
      H5Lcreate_soft("/entry_1/experiment_identifier",img.self,"experiment_identifier",H5P_DEFAULT,H5P_DEFAULT);
      cxi->entry.images.push_back(img);

      if(global->detector[detID].downsampling > 1){
	// /entry_1/image_j
	sprintf(imageName,"/entry_1/image_%ld",global->nDetectors+detID+1);
	CXI::Image imgXxX;
	imgXxX.self = H5Gcreate(cxi->entry.self, imageName, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
	// /entry_1/image_j/data
	long imageXxX_ny = global->detector[detID].imageXxX_nn/global->detector[detID].imageXxX_nx;
	imgXxX.data = create2DStack("data", imgXxX.self, global->detector[detID].imageXxX_nx, imageXxX_ny, H5T_STD_I16LE);
	if(global->savePixelmask){
	  // /entry_1/image_j/mask
	  imgXxX.mask = create2DStack("mask", imgXxX.self, global->detector[detID].imageXxX_nx, imageXxX_ny, H5T_NATIVE_UINT16);
	}
	// /entry_1/image_j/mask_shared
	uint16_t *imageXxX_pixelmask_shared = (uint16_t*) calloc(global->detector[detID].imageXxX_nn,sizeof(uint16_t));
	downsampleMask(image_pixelmask_shared,imageXxX_pixelmask_shared,global->detector[detID].image_nn,global->detector[detID].image_nx,global->detector[detID].imageXxX_nn,global->detector[detID].imageXxX_nx);
	createAndWriteDataset("mask_shared", imgXxX.self, imageXxX_pixelmask_shared, global->detector[detID].imageXxX_nx, imageXxX_ny);
	// /entry_1/image_j/detector_1
	H5Lcreate_soft(detectorPath,imgXxX.self,"detector_1",H5P_DEFAULT,H5P_DEFAULT);
	// /entry_1/image_j/source_1
	H5Lcreate_soft("/entry_1/instrument_1/source_1",imgXxX.self,"source_1",H5P_DEFAULT,H5P_DEFAULT);
	// /entry_1/image_j/data_type
	imgXxX.dataType = createStringStack("data_type",imgXxX.self);
	// /entry_1/image_j/data_space
	imgXxX.dataSpace = createStringStack("data_space",imgXxX.self);
	// /entry_1/image_j/thumbnail
	imgXxX.thumbnail = create2DStack("thumbnail", imgXxX.self, global->detector[detID].imageXxX_nx/CXI::thumbnailScale, imageXxX_ny/CXI::thumbnailScale, H5T_STD_I16LE);
	// /entry_1/image_j/experiment_identifier
	H5Lcreate_soft("/entry_1/experiment_identifier",imgXxX.self,"experiment_identifier",H5P_DEFAULT,H5P_DEFAULT);
	cxi->entry.images.push_back(imgXxX);
	free(imageXxX_pixelmask_shared);
      }
      free(image_pixelmask_shared);
    }
  }

  cxi->lcls.self = H5Gcreate(cxi->self, "LCLS", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  cxi->lcls.machineTime = createScalarStack("machineTime", cxi->lcls.self, H5T_NATIVE_INT32);
  cxi->lcls.fiducial = createScalarStack("fiducial", cxi->lcls.self, H5T_NATIVE_INT32);
  cxi->lcls.ebeamCharge = createScalarStack("ebeamCharge", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.ebeamL3Energy = createScalarStack("ebeamL3Energy", cxi->lcls.self, H5T_NATIVE_DOUBLE);
  cxi->lcls.ebeamPkCurrBC2 = createScalarStack("ebeamPkCurrBC2", cxi->lcls.self, H5T_NATIVE_DOUBLE);
  cxi->lcls.ebeamLTUPosX = createScalarStack("ebeamLTUPosX", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.ebeamLTUPosY = createScalarStack("ebeamLTUPosY", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.ebeamLTUAngX = createScalarStack("ebeamLTUAngX", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.ebeamLTUAngY = createScalarStack("ebeamLTUAngY", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.phaseCavityTime1 = createScalarStack("phaseCavityTime1", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.phaseCavityTime2 = createScalarStack("phaseCavityTime2", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.phaseCavityCharge1 = createScalarStack("phaseCavityCharge1", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.phaseCavityCharge2 = createScalarStack("phaseCavityCharge2", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.photon_energy_eV = createScalarStack("photon_energy_eV", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.photon_wavelength_A = createScalarStack("photon_wavelength_A", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.f_11_ENRC = createScalarStack("f_11_ENRC", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.f_12_ENRC = createScalarStack("f_12_ENRC", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.f_21_ENRC = createScalarStack("f_21_ENRC", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.f_22_ENRC = createScalarStack("f_22_ENRC", cxi->lcls.self,H5T_NATIVE_DOUBLE);
  cxi->lcls.evr41 = createScalarStack("evr41", cxi->lcls.self,H5T_NATIVE_INT);
  cxi->lcls.eventTimeString = createStringStack("eventTimeString", cxi->lcls.self);
  H5Lcreate_soft("/LCLS/eventTimeString", cxi->self, "/LCLS/eventTime",H5P_DEFAULT,H5P_DEFAULT);
  H5Lcreate_soft("/entry_1/experiment_identifier",cxi->lcls.self,"experiment_identifier",H5P_DEFAULT,H5P_DEFAULT);

  DETECTOR_LOOP{
    char buffer[1024];
    sprintf(buffer,"detector%li-position", detID +1);
    cxi->lcls.detector_positions.push_back(createScalarStack(buffer, cxi->lcls.self,H5T_NATIVE_DOUBLE));
    sprintf(buffer,"detector%li-EncoderValue", detID +1);
    cxi->lcls.detector_EncoderValues.push_back(createScalarStack(buffer, cxi->lcls.self,H5T_NATIVE_DOUBLE));
  }

  // Save cheetah variables  
  cxi->cheetahVal.self = H5Gcreate(cxi->self, "cheetah", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);

  cxi->cheetahVal.unsharedVal.self = H5Gcreate(cxi->cheetahVal.self, "unshared", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);

  cxi->cheetahVal.unsharedVal.eventName = createStringStack("eventName", cxi->cheetahVal.unsharedVal.self,1024);
  cxi->cheetahVal.unsharedVal.frameNumber = createScalarStack("frameNumber", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_LONG);
  cxi->cheetahVal.unsharedVal.threadID = createScalarStack("threadID", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_LONG);
  cxi->cheetahVal.unsharedVal.gmd1 = createScalarStack("gmd1", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_DOUBLE);
  cxi->cheetahVal.unsharedVal.gmd2 = createScalarStack("gmd2", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_DOUBLE);
  cxi->cheetahVal.unsharedVal.energySpectrumExist = createScalarStack("energySpectrumExist", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_INT);
  cxi->cheetahVal.unsharedVal.nPeaks = createScalarStack("nPeaks", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_INT);  
  cxi->cheetahVal.unsharedVal.peakNpix = createScalarStack("peakNpix", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_FLOAT);  
  cxi->cheetahVal.unsharedVal.peakTotal = createScalarStack("peakTotal", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_FLOAT);  
  cxi->cheetahVal.unsharedVal.peakResolution = createScalarStack("peakResolution", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_FLOAT);  
  cxi->cheetahVal.unsharedVal.peakResolutionA = createScalarStack("peakResolutionA", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_FLOAT);  
  cxi->cheetahVal.unsharedVal.peakDensity = createScalarStack("peakDensity", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_FLOAT);  
  cxi->cheetahVal.unsharedVal.laserEventCodeOn = createScalarStack("laserEventCodeOn", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_INT);
  cxi->cheetahVal.unsharedVal.laserDelay = createScalarStack("laserDelay", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_DOUBLE);
  cxi->cheetahVal.unsharedVal.hit = createScalarStack("hit", cxi->cheetahVal.unsharedVal.self,H5T_NATIVE_INT);
  
  cxi->cheetahVal.sharedVal.self = H5Gcreate(cxi->cheetahVal.self, "shared", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
 
  CXI::ConfValues confVal;
  cxi->cheetahVal.confVal.self = H5Gcreate(cxi->cheetahVal.self, "configuration", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
  confVal = cxi->cheetahVal.confVal;

  DETECTOR_LOOP{
    char buffer[1024];
    sprintf(buffer,"detector%ld_lastBgUpdate",detID);
    cxi->cheetahVal.sharedVal.lastBgUpdate[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_nHot",detID);
    cxi->cheetahVal.sharedVal.nHot[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_lastHotPixUpdate",detID);
    cxi->cheetahVal.sharedVal.lastHotPixUpdate[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_hotPixCounter",detID);
    cxi->cheetahVal.sharedVal.hotPixCounter[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_nHalo",detID);
    cxi->cheetahVal.sharedVal.nHalo[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_lastHaloPixUpdate",detID);
    cxi->cheetahVal.sharedVal.lastHaloPixUpdate[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_haloPixCounter",detID);
    cxi->cheetahVal.sharedVal.haloPixCounter[detID] = createScalarStack(buffer, cxi->cheetahVal.sharedVal.self,H5T_NATIVE_LONG);
    sprintf(buffer,"detector%ld_detectorName",detID);
    createAndWriteDataset(buffer,confVal.self,global->detector[detID].detectorName,MAX_FILENAME_LENGTH);
    sprintf(buffer,"detector%ld_geometryFile",detID);
    createAndWriteDataset(buffer,confVal.self,global->detector[detID].geometryFile,MAX_FILENAME_LENGTH);
    sprintf(buffer,"detector%ld_darkcalFile",detID);
    createAndWriteDataset(buffer,confVal.self,global->detector[detID].darkcalFile,MAX_FILENAME_LENGTH);
    sprintf(buffer,"detector%ld_gaincalFile",detID);
    createAndWriteDataset(buffer,confVal.self,global->detector[detID].gaincalFile,MAX_FILENAME_LENGTH);
    sprintf(buffer,"detector%ld_badpixelFile",detID);
    createAndWriteDataset(buffer,confVal.self,global->detector[detID].badpixelFile,MAX_FILENAME_LENGTH);
    sprintf(buffer,"detector%ld_wireMaskFile",detID);
    createAndWriteDataset(buffer,confVal.self,global->detector[detID].wireMaskFile,MAX_FILENAME_LENGTH);
    sprintf(buffer,"detector%ld_pixelSize",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].pixelSize);
    sprintf(buffer,"detector%ld_cmModule",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].cmModule);
    sprintf(buffer,"detector%ld_cspadSubtractUnbondedPixels",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].cspadSubtractUnbondedPixels);
    sprintf(buffer,"detector%ld_cspadSubtractBehindWires",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].cspadSubtractBehindWires);
    sprintf(buffer,"detector%ld_invertGain",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].invertGain);
    sprintf(buffer,"detector%ld_saveDetectorCorrectedOnly",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].saveDetectorCorrectedOnly);
    sprintf(buffer,"detector%ld_saveDetectorRaw",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].saveDetectorRaw);
    sprintf(buffer,"detector%ld_useAutoHotpixel",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].useAutoHotpixel);
    sprintf(buffer,"detector%ld_maskSaturatedPixels",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].maskSaturatedPixels);
    sprintf(buffer,"detector%ld_pixelSaturationADC",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].pixelSaturationADC);
    sprintf(buffer,"detector%ld_useSubtractPersistentBackground",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].useSubtractPersistentBackground);
    sprintf(buffer,"detector%ld_useBackgroundBufferMutex",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].useBackgroundBufferMutex);
    sprintf(buffer,"detector%ld_useLocalBackgroundSubtraction",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].useLocalBackgroundSubtraction);
    sprintf(buffer,"detector%ld_cmFloor",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].cmFloor);
    sprintf(buffer,"detector%ld_hotpixFreq",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].hotpixFreq);
    sprintf(buffer,"detector%ld_hotpixADC",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].hotpixADC);
    sprintf(buffer,"detector%ld_hotpixMemory",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].hotpixMemory);
    sprintf(buffer,"detector%ld_bgMemory",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].bgMemory);
    sprintf(buffer,"detector%ld_bgRecalc",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].bgRecalc);
    sprintf(buffer,"detector%ld_bgMedian",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].bgMedian);
    sprintf(buffer,"detector%ld_bgIncludeHits",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].bgIncludeHits);
    sprintf(buffer,"detector%ld_bgNoBeamReset",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].bgNoBeamReset);
    sprintf(buffer,"detector%ld_scaleBackground",detID);
    createAndWriteDataset(buffer,confVal.self,&global->detector[detID].scaleBackground);
    //sprintf(buffer,"detector%ld_X",detID);
    //createAndWriteDataset(buffer,confVal.self,&global->detector[detID].X);
  }

  createAndWriteDataset("defaultPhotonEnergyeV",confVal.self,&global->defaultPhotonEnergyeV);
  createAndWriteDataset("startAtFrame",confVal.self,&global->startAtFrame);
  createAndWriteDataset("stopAtFrame",confVal.self,&global->stopAtFrame);
  createAndWriteDataset("nThreads",confVal.self,&global->nThreads);
  createAndWriteDataset("useHelperThreads",confVal.self,&global->useHelperThreads);
  createAndWriteDataset("ioSpeedTest",confVal.self,&global->ioSpeedTest);
  createAndWriteDataset("threadPurge",confVal.self,&global->threadPurge);
  createAndWriteDataset("peaksearchFile",confVal.self,global->peaksearchFile,MAX_FILENAME_LENGTH);
  createAndWriteDataset("generateDarkcal",confVal.self,&global->generateDarkcal);
  createAndWriteDataset("generateGaincal",confVal.self,&global->generateGaincal);
  createAndWriteDataset("hitfinder",confVal.self,&global->hitfinder);
  createAndWriteDataset("savehits",confVal.self,&global->savehits);
  createAndWriteDataset("saveRaw",confVal.self,&global->saveRaw);
  createAndWriteDataset("saveAssembled",confVal.self,&global->saveAssembled);
  createAndWriteDataset("assembleInterpolation",confVal.self,&global->assembleInterpolation);
  createAndWriteDataset("hdf5dump",confVal.self,&global->hdf5dump);
  createAndWriteDataset("saveInterval",confVal.self,&global->saveInterval);
  createAndWriteDataset("savePixelmask",confVal.self,&global->savePixelmask);
  createAndWriteDataset("tofName",confVal.self,global->tofName);
  createAndWriteDataset("TOFchannel",confVal.self,&global->TOFchannel);
  createAndWriteDataset("hitfinderUseTOF",confVal.self,&global->hitfinderUseTOF);
  createAndWriteDataset("hitfinderTOFMinSample",confVal.self,&global->hitfinderTOFMinSample);
  createAndWriteDataset("hitfinderTOFMaxSample",confVal.self,&global->hitfinderTOFMaxSample);
  createAndWriteDataset("hitfinderTOFThresh",confVal.self,&global->hitfinderTOFThresh);
  createAndWriteDataset("saveRadialStacks",confVal.self,&global->saveRadialStacks);
  createAndWriteDataset("radialStackSize",confVal.self,&global->radialStackSize);
  createAndWriteDataset("espectrum1D",confVal.self,&global->espectrum1D);
  createAndWriteDataset("espectrumTiltAng",confVal.self,&global->espectrumTiltAng);
  createAndWriteDataset("espectrumLength",confVal.self,&global->espectrumLength);
  createAndWriteDataset("espectrumSpreadeV",confVal.self,&global->espectrumSpreadeV);
  createAndWriteDataset("espectrumDarkSubtract",confVal.self,&global->espectrumDarkSubtract);
  createAndWriteDataset("espectrumDarkFile",confVal.self,global->espectrumDarkFile,MAX_FILENAME_LENGTH);
  createAndWriteDataset("espectrumScaleFile",confVal.self,global->espectrumScaleFile,MAX_FILENAME_LENGTH);
  createAndWriteDataset("debugLevel",confVal.self,&global->debugLevel);
  createAndWriteDataset("powderthresh",confVal.self,&global->powderthresh);
  createAndWriteDataset("powderSumHits",confVal.self,&global->powderSumHits);
  createAndWriteDataset("powderSumBlanks",confVal.self,&global->powderSumBlanks);
  createAndWriteDataset("hitfinderADC",confVal.self,&global->hitfinderADC);
  createAndWriteDataset("hitfinderCheckGradient",confVal.self,&global->hitfinderCheckGradient);
  createAndWriteDataset("hitfinderMinGradient",confVal.self,&global->hitfinderMinGradient);
  createAndWriteDataset("hitfinderCluster",confVal.self,&global->hitfinderCluster);
  createAndWriteDataset("hitfinderNpeaks",confVal.self,&global->hitfinderNpeaks);
  createAndWriteDataset("hitfinderAlgorithm",confVal.self,&global->hitfinderAlgorithm);
  createAndWriteDataset("hitfinderMinPixCount",confVal.self,&global->hitfinderMinPixCount);
  createAndWriteDataset("hitfinderMaxPixCount",confVal.self,&global->hitfinderMaxPixCount);
  createAndWriteDataset("hitfinderMinPeakSeparation",confVal.self,&global->hitfinderMinPeakSeparation);
  createAndWriteDataset("hitfinderSubtractLocalBG",confVal.self,&global->hitfinderSubtractLocalBG);
  createAndWriteDataset("hitfinderLocalBGRadius",confVal.self,&global->hitfinderLocalBGRadius);
  createAndWriteDataset("hitfinderLocalBGThickness",confVal.self,&global->hitfinderLocalBGThickness);
  createAndWriteDataset("hitfinderMinRes",confVal.self,&global->hitfinderMinRes);
  createAndWriteDataset("hitfinderMaxRes",confVal.self,&global->hitfinderMaxRes);
  createAndWriteDataset("hitfinderResolutionUnitPixel",confVal.self,&global->hitfinderResolutionUnitPixel);
  createAndWriteDataset("hitfinderMinSNR",confVal.self,&global->hitfinderMinSNR);
  createAndWriteDataset("saveCXI",confVal.self,&global->saveCXI);

  return cxi;
}

static std::vector<std::string> openFilenames = std::vector<std::string>();
static std::vector<CXI::File* > openFiles = std::vector<CXI::File *>();

static CXI::File * getCXIFileByName(cGlobal *global){
  char * filename = global->cxiFilename;
  pthread_mutex_lock(&global->framefp_mutex);
  /* search again to be sure */
  for(uint i = 0;i<openFilenames.size();i++){
    if(openFilenames[i] == std::string(filename)){
      pthread_mutex_unlock(&global->framefp_mutex);
      return openFiles[i];
    }
  }
  openFilenames.push_back(filename);
  CXI::File * cxi = createCXISkeleton(filename,global);
  openFiles.push_back(cxi);
  pthread_mutex_unlock(&global->framefp_mutex);
  return cxi;
}

void writeAccumulatedCXI(cGlobal * global){
  CXI::File * cxi = getCXIFileByName(global);
  CXI::SharedValues sharedVal = cxi->cheetahVal.sharedVal;

  cPixelDetectorCommon *detector;
  long	radial_nn;
  long	pix_nn,pix_nx,pix_ny;
  long	image_nn;

  DETECTOR_LOOP{
    POWDER_LOOP{
      detector = &global->detector[detID];
      radial_nn = detector->radial_nn;
      pix_nn =  detector->pix_nn;
      pix_nx =  detector->pix_nx;
      pix_ny =  detector->pix_ny;
      image_nn = detector->image_nn;
      char buffer[1024];

      // Dereference/create arrays to be written to file
      // SUM(data)
      double * sum_raw = detector->powderRaw[powID];
      double * sum_corrected = detector->powderCorrected[powID];
      double * sum_corrected_ang = (double*) calloc(radial_nn, sizeof(double));
      double * sum_corrected_angCnt = (double*) calloc(radial_nn, sizeof(double));
      calculateRadialAverage(sum_corrected,sum_corrected_ang,sum_corrected_angCnt,global,detID);

      // SUM(data*data)
      double * sum_rawSq = detector->powderRawSquared[powID];
      double * sum_correctedSq = detector->powderCorrectedSquared[powID];
      double * sum_correctedSq_ang = (double*) calloc(radial_nn, sizeof(double));
      double * sum_correctedSq_angCnt = (double*) calloc(radial_nn, sizeof(double));
      calculateRadialAverage(sum_correctedSq,sum_correctedSq_ang,sum_correctedSq_angCnt,global,detID);

      // SIGMA(data) = sqrt(SUM(data*data)-SUM(data)*SUM(data)) / N
      double * sigma_raw = (double *) calloc(pix_nn,sizeof(double));
      for(long i = 0; i<pix_nn; i++){
	sigma_raw[i] =
	  sqrt( fabs(sum_rawSq[i] - sum_raw[i]*sum_raw[i]) / detector->nPowderFrames[powID] );
      }
      double * sigma_corrected = (double *) calloc(pix_nn,sizeof(double));
      for(long i = 0; i<pix_nn; i++){
	sigma_corrected[i] =
	  sqrt( fabs(sum_correctedSq[i] - sum_corrected[i]*sum_corrected[i]) / detector->nPowderFrames[powID] );
      }      
      double * sigma_corrected_ang = (double*) calloc(radial_nn, sizeof(double));
      double * sigma_corrected_angCnt = (double*) calloc(radial_nn, sizeof(double));
      calculateRadialAverage(sum_corrected,sum_corrected_ang,sum_corrected_angCnt,global,detID);

      // SUM(data)
      sprintf(buffer,"detector%li_class%li_sum_raw",detID,powID);
      createAndWriteDataset(buffer, cxi->cheetahVal.sharedVal.self,sum_raw,pix_nx,pix_ny);
      sprintf(buffer,"detector%li_class%li_sum_corrected",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sum_corrected,pix_nx,pix_ny);
      sprintf(buffer,"detector%li_class%li_sum_corrected_angAvg",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sum_corrected_ang,radial_nn);

      // SUM(data*data)
      sprintf(buffer,"detector%li_class%li_sum_rawSq",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sum_rawSq,pix_nx,pix_ny);
      sprintf(buffer,"detector%li_class%li_sum_correctedSq",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sum_correctedSq,pix_nx,pix_ny);
      sprintf(buffer,"detector%li_class%li_sum_correctedSq_angAvg",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sum_correctedSq_ang,radial_nn);

      // SIGMA(data)
      sprintf(buffer,"detector%li_class%li_sigma_raw",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sigma_raw,pix_nx,pix_ny);
      sprintf(buffer,"detector%li_class%li_sigma_corrected",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sigma_corrected,pix_nx,pix_ny);
      sprintf(buffer,"detector%li_class%li_sigma_corrected_angAvg",detID,powID);
      createAndWriteDataset(buffer, sharedVal.self,sigma_corrected_ang,radial_nn);
      
      free(sum_corrected_ang);
      free(sum_corrected_angCnt);
      free(sum_correctedSq_ang);
      free(sum_correctedSq_angCnt);
      free(sigma_corrected_ang);
      free(sigma_corrected_angCnt);
    }      
  }
}

static void  closeCXI(CXI::File * cxi){
  hid_t ids[256];
  int n_ids = H5Fget_obj_ids(cxi->self, H5F_OBJ_DATASET, 256, ids);
  for (int i=0; i<n_ids; i++){
    //H5I_type_t type;
    hsize_t block[3];
    hsize_t mdims[3];
    hid_t dataspace = H5Dget_space (ids[i]);
    if( dataspace<0 ) {ERROR("Cannot get dataspace.\n");}
    H5Sget_simple_extent_dims(dataspace, block, mdims);
    if(mdims[0] == H5S_UNLIMITED){
      block[0] = cxi->stackCounter;
      H5Dset_extent(ids[i], block);
    }
  }
}

void closeCXIFiles(cGlobal * global){
#if H5_VERS_MAJOR == 1 && H5_VERS_MINOR == 8 && H5_VERS_RELEASE < 9
#warning "HDF5 < 1.8.9 contains a bug which makes it impossible to shrink certain datasets.\n"
#warning "Please update your HDF5 to get properly truncated output files.\n"
  fprintf(stderr,"HDF5 < 1.8.9 contains a bug which makes it impossible to shrink certain datasets.\n");
  fprintf(stderr,"Please update your HDF5 to get properly truncated output files.\n");
#else
  pthread_mutex_lock(&global->framefp_mutex);
  /* Go through each file and resize them to their right size */
  for(uint i = 0;i<openFilenames.size();i++){
    closeCXI(openFiles[i]);    
  }
  openFiles.clear();
  openFilenames.clear();
  pthread_mutex_unlock(&global->framefp_mutex);
#endif
  H5close();
}

void writeCXI(cEventData *info, cGlobal *global ){
  /* Get the existing CXI file or open a new one */
  CXI::File * cxi = getCXIFileByName(global);
  uint stackSlice = getStackSlice(cxi);
  info->stackSlice = stackSlice;
  //printf("Writing to CXI file for stack slice number %ld \n", stackSlice);
  
  double en = info->photonEnergyeV * 1.60217646e-19;
  writeScalarToStack(cxi->entry.instrument.source.energy,stackSlice,en);
  // remove the '.h5' from eventname
  info->eventname[strlen(info->eventname) - 3] = 0;
  writeStringToStack(cxi->entry.experimentIdentifier,stackSlice,info->eventname);
  // put it back
  info->eventname[strlen(info->eventname)] = '.';

  DETECTOR_LOOP {    
    /* Save assembled image under image groups */
    writeScalarToStack(cxi->entry.instrument.detectors[detID].distance,stackSlice,global->detector[detID].detectorZ/1000.0);
    writeScalarToStack(cxi->entry.instrument.detectors[detID].xPixelSize,stackSlice,global->detector[detID].pixelSize);
    writeScalarToStack(cxi->entry.instrument.detectors[detID].yPixelSize,stackSlice,global->detector[detID].pixelSize);

    long imgID = detID;
    if (global->detector[detID].downsampling > 1){
      imgID = detID * 2;
    }
    char buffer[1024];
    long image_ny = global->detector[detID].image_nn/global->detector[detID].image_nx;
    sprintf(buffer,"%s [%s]",global->detector[detID].detectorType,global->detector[detID].detectorName);
    writeStringToStack(cxi->entry.instrument.detectors[detID].description,stackSlice,buffer);
    if(global->saveAssembled){
      if (cxi->entry.images[imgID].data<0) {ERROR("No valid dataset.");}
      write2DToStack(cxi->entry.images[imgID].data,stackSlice,info->detector[detID].image);
      if(global->savePixelmask){
	if (cxi->entry.images[imgID].mask<0) {ERROR("No valid dataset.");}
	write2DToStack(cxi->entry.images[imgID].mask,stackSlice,info->detector[detID].image_pixelmask);
      }
      int16_t * thumbnail = generateThumbnail(info->detector[detID].image,global->detector[detID].image_nx,image_ny,CXI::thumbnailScale);
      if (cxi->entry.images[imgID].thumbnail<0){ERROR("No valid dataset.");}
      write2DToStack(cxi->entry.images[imgID].thumbnail,stackSlice,thumbnail);
      writeStringToStack(cxi->entry.images[imgID].dataType,stackSlice,"intensities");
      writeStringToStack(cxi->entry.images[imgID].dataSpace,stackSlice,"diffraction");
      delete [] thumbnail;      

      if (global->detector[detID].downsampling > 1){
	imgID = detID * 2 + 1;
	long imageXxX_ny = global->detector[detID].imageXxX_nn/global->detector[detID].imageXxX_nx;
	if (cxi->entry.images[imgID].data<0) {ERROR("No valid dataset.");}
	write2DToStack(cxi->entry.images[imgID].data,stackSlice,info->detector[detID].imageXxX);
	if(global->savePixelmask){
	  if (cxi->entry.images[imgID].mask<0) {ERROR("No valid dataset.");}
	  write2DToStack(cxi->entry.images[imgID].mask,stackSlice,info->detector[detID].imageXxX_pixelmask);
	}
	int16_t * thumbnail = generateThumbnail(info->detector[detID].imageXxX,global->detector[detID].imageXxX_nx,imageXxX_ny,CXI::thumbnailScale);
	if (cxi->entry.images[imgID].thumbnail<0){ERROR("No valid dataset.");}
	write2DToStack(cxi->entry.images[imgID].thumbnail,stackSlice,thumbnail);
	writeStringToStack(cxi->entry.images[imgID].dataType,stackSlice,"intensities");
	writeStringToStack(cxi->entry.images[imgID].dataSpace,stackSlice,"diffraction");
	delete [] thumbnail;
      }
    }
    if(global->saveRaw){
      if (cxi->entry.instrument.detectors[detID].data<0){ERROR("No valid dataset.");}
      write2DToStack(cxi->entry.instrument.detectors[detID].data,stackSlice,info->detector[detID].corrected_data_int16);
      if(global->savePixelmask){
	write2DToStack(cxi->entry.instrument.detectors[detID].mask,stackSlice,info->detector[detID].pixelmask);
      }
      int16_t * thumbnail = generateThumbnail(info->detector[detID].corrected_data_int16,global->detector[detID].pix_nx,global->detector[detID].pix_ny,CXI::thumbnailScale);
      write2DToStack(cxi->entry.instrument.detectors[detID].thumbnail,stackSlice,thumbnail);
      delete [] thumbnail;
    }
  }
  /*Write LCLS informations*/
  DETECTOR_LOOP{
    writeScalarToStack(cxi->lcls.detector_positions[detID],stackSlice,global->detector[detID].detectorZ);
    writeScalarToStack(cxi->lcls.detector_EncoderValues[detID],stackSlice,detID);
  }
  writeScalarToStack(cxi->lcls.machineTime,stackSlice,info->seconds);
  writeScalarToStack(cxi->lcls.fiducial,stackSlice,info->fiducial);
  writeScalarToStack(cxi->lcls.ebeamCharge,stackSlice,info->fEbeamCharge);
  writeScalarToStack(cxi->lcls.ebeamL3Energy,stackSlice,info->fEbeamL3Energy);
  writeScalarToStack(cxi->lcls.ebeamLTUAngX,stackSlice,info->fEbeamLTUAngX);
  writeScalarToStack(cxi->lcls.ebeamLTUAngY,stackSlice,info->fEbeamLTUAngY);
  writeScalarToStack(cxi->lcls.ebeamLTUPosX,stackSlice,info->fEbeamLTUPosX);
  writeScalarToStack(cxi->lcls.ebeamLTUPosY,stackSlice,info->fEbeamLTUPosY);
  writeScalarToStack(cxi->lcls.ebeamPkCurrBC2,stackSlice,info->fEbeamPkCurrBC2);
  writeScalarToStack(cxi->lcls.phaseCavityTime1,stackSlice,info->phaseCavityTime1);
  writeScalarToStack(cxi->lcls.phaseCavityTime2,stackSlice,info->phaseCavityTime2);
  writeScalarToStack(cxi->lcls.phaseCavityCharge1,stackSlice,info->phaseCavityCharge1);
  writeScalarToStack(cxi->lcls.phaseCavityCharge2,stackSlice,info->phaseCavityCharge2);
  writeScalarToStack(cxi->lcls.photon_energy_eV,stackSlice,info->photonEnergyeV);
  writeScalarToStack(cxi->lcls.photon_wavelength_A,stackSlice,info->wavelengthA);
  writeScalarToStack(cxi->lcls.f_11_ENRC,stackSlice,info->gmd11);
  writeScalarToStack(cxi->lcls.f_12_ENRC,stackSlice,info->gmd12);
  writeScalarToStack(cxi->lcls.f_21_ENRC,stackSlice,info->gmd21);
  writeScalarToStack(cxi->lcls.f_22_ENRC,stackSlice,info->gmd22);
  int LaserOnVal = (info->laserEventCodeOn)?1:0;
  writeScalarToStack(cxi->lcls.evr41,stackSlice,LaserOnVal);
  char timestr[26];
  time_t eventTime = info->seconds;
  ctime_r(&eventTime,timestr);
  writeStringToStack(cxi->lcls.eventTimeString,stackSlice,timestr);
  
  writeStringToStack(cxi->cheetahVal.unsharedVal.eventName,stackSlice,info->eventname);
  writeScalarToStack(cxi->cheetahVal.unsharedVal.frameNumber,stackSlice,info->frameNumber);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.threadID,stackSlice,info->threadNum);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.gmd1,stackSlice,info->gmd1);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.gmd2,stackSlice,info->gmd2);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.energySpectrumExist,stackSlice,info->energySpectrumExist);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.nPeaks,stackSlice,info->nPeaks);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.peakNpix,stackSlice,info->peakNpix);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.peakTotal,stackSlice,info->peakTotal);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.peakResolution,stackSlice,info->peakResolution);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.peakResolutionA,stackSlice,info->peakResolutionA);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.peakDensity,stackSlice,info->peakDensity);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.laserEventCodeOn,stackSlice,info->laserEventCodeOn);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.laserDelay,stackSlice,info->laserDelay);  
  writeScalarToStack(cxi->cheetahVal.unsharedVal.hit,stackSlice,info->hit);
  

  DETECTOR_LOOP{
    writeScalarToStack(cxi->cheetahVal.sharedVal.lastBgUpdate[detID],stackSlice,global->detector[detID].last_bg_update);  
    writeScalarToStack(cxi->cheetahVal.sharedVal.nHot[detID],stackSlice,global->detector[detID].nhot);  
    writeScalarToStack(cxi->cheetahVal.sharedVal.lastHotPixUpdate[detID],stackSlice,global->detector[detID].last_hotpix_update);  
    writeScalarToStack(cxi->cheetahVal.sharedVal.hotPixCounter[detID],stackSlice,global->detector[detID].hotpixCounter);  
    writeScalarToStack(cxi->cheetahVal.sharedVal.nHalo[detID],stackSlice,global->detector[detID].nhalo);  
    writeScalarToStack(cxi->cheetahVal.sharedVal.lastHaloPixUpdate[detID],stackSlice,global->detector[detID].last_halopix_update);  
    writeScalarToStack(cxi->cheetahVal.sharedVal.haloPixCounter[detID],stackSlice,global->detector[detID].halopixCounter);  
  }
}
