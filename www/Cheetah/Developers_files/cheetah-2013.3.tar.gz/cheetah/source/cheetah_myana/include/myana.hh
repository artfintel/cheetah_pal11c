/* $Id: myana.hh,v 1.4 2010/07/17 00:24:14 caf Exp $ */
#ifndef MYANA_H
#define MYANA_H

void beginjob();
void beginrun();
void begincalib();
void event();
void endcalib();
void endrun();
void endjob();

#endif
