
export XTCDIR="/reg/d/ana02/cxi/cxi29411/xtc"
export H5DIR="/reg/d/ana02/cxi/cxi29411/scratch/rkirian/hdf5"
export CONFIGDIR="/reg/neh/home/rkirian/cxi/cxi29411/scripts/config"
export TMPDIR="/reg/d/ana02/cxi/cxi29411/scratch/rkirian/tmp"
export CHEETAH="/reg/neh/home/rkirian/cxi/cxi29411/cheetah/cheetah"

